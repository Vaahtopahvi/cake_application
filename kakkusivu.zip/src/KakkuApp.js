import React from "react";
import { useState } from "react";
import Kategoriat from "./components/Kategoriat";
import Kakut from "./components/Kakut";
import Kortit from "./components/Kortit";
import { BrowserRouter } from "react-router-dom";
//import NavBar from "./components/NavBar";
//import TabsMUI from "./TabsMUI";


const KakkuApp = () => {
  const [resepti, setResepti] = useState([
    { 
    id: 1,
    kategoria: "kakut",
    title: "Paistettu Juustokakku",
    monelle: "10-12 hlölle",
    laatija: "Ilona Tjurin",
    image: require('./Kuvat/paistettu_juustokakku.jpg'),
    ainekset: 
      ["300g digestive-keksejä",<br></br>,
      "150g voita",<br></br>,
      "600g maustamatonta tuorejuustoa",<br></br>,
      "200g smetanaa (yli 25%)",<br></br>,
      "130g kuohukermaa",<br></br>,
      "3 munaa",<br></br>,
      "1 keltuainen",<br></br>,
      "150g sokeria",<br></br>,
      "40g maissitärkkelystä",<br></br>,
    ],
    ohjeet: 
      ["1. Murskaa keksit pieneksi ja sekoita tasaiseksi voisulan kanssa.",<br></br>,
      "2. Levitä voi-keksiseos leivinpaperilla vuoratun vuoan pohjalle ja reunoille.",<br></br>,
      "3. Laita pohja jääkaappiin odottamaan.",<br></br>,
      "4. Yhdistä ja sekoita tasaiseksi (älä vatkaa) tuorejuusto, kuohukerma, smetana ja munat.",<br></br>,
      "5. Sekoita keskenään toisessa kulhossa sokeri ja maissitärkkelys. Lisää tuorejuustoseokseen. Sekoita tasaiseksi.",<br></br>,
      "6. Kaada taikina vuokaan ja paista 110 asteessa uunin keskitasolla 3-3,5h. Matala lämpötila ja pitkä paistoaika tekevät juustokakusta pehmoisen sisältä ja sileän päältä.",<br></br>,
      "7. Tarkista kakun kypsyys liikuttamalla varovasti vuokaa. Kakku on valmis, kun juustokakku on reunoilta jämäkkä, mutta hyllyy vielä vähän keskikohdasta.",<br></br>,
      "8. Jäähdytä kakku huoneenlämmössä, laita kelmu päälle ja laita yöksi jääkaappiin asettumaan. (Kakun on oltava jääkaapissa vähintään 4-5h, mieluiten aina yön yli.)",<br></br>,
      "9. Levitä valmiin kakun päälle lemon curdia ja mustikoita, tai muita haluamiasi koristeita.",<br></br>,
    ]
    },
    {
      id: 2,
      kategoria: "kakut",
      title: "Mehevät Porkkanakakkupohjat",
      monelle: "10-12 hlölle",
      laatija: "Ilona Tjurin",
      image: require('./Kuvat/porkkanakakkupohja.jpg'),
      ainekset:
      [
        "3-4 porkkanaa (n. 400g)",<br></br>,
        "2dl sokeria",<br></br>,
        "3 munaa",<br></br>,
        "4dl jauhoja",<br></br>,
        "2tl leivinjauhetta",<br></br>,
        "2tl ruokasoodaa",<br></br>,
        "1tl kanelia",<br></br>,
        "1/2 tl muskottipähkinää (tai inkivääriä)",<br></br>,
        "1/2tl suolaa",<br></br>,
        "100g saksanpähkinää rouheena",<br></br>,
        "1,5dl rypsiöljyä"
      ],
      ohjeet:
      [
        "1. Vuoraa leivinpaperilla kaksi halk. 15cm vuokaa.",<br></br>,

        "2. Kuori ja raasta porkkanat. Sekoita raaste haarukalla yhdessä sokerin kanssa isossa kulhossa. Sekoita ja painele siihen asti, että porkkanaraasteesta alkaa erottua mehua.",<br></br>,
        
        "3. Lisää munat joukkoon ja sekoita huolellisesti vispilällä.",<br></br>,
        
        "4. Yhdistä ja siivilöi kaikki kuivat aineet omassa kulhossa (paitsi pähkinät).",<br></br>,
        
        "5. Lisää kuivat aineet taikinan joukkoon. Sekoita.",<br></br>,
        
        "6. Lisää pähkinärouhe. Sekoita.",<br></br>,
        
        "7. Lisää öljy. Sekoita huolellisesti.",<br></br>,
        
        "8. Jaa taikina kahteen vuokaan ja paista 170 asteessa uunin keskitasolla 40-45min. Tarkista kypsyys tikulla.",<br></br>,
        
        "Kumoa valmiit kakut ritilälle ja anna jäähtyä liinan alla huoneenlämmössä. Kääri kakut kelmuun ja laita jääkaappiin mielellään yön yli. Leikkaa ja täytä vasta seuraavana päivänä."
      ]
    },
    {
      id: 3,
      kategoria: "marengit",
      title: "Suloiset marenkimuumiot",
      monelle: "2 pellillistä",
      laatija: "Ilona Tjurin",
      image: require('./Kuvat/marenki_muumiot.jpg'),
      ainekset:
      [
        "3 valkuaista",<br></br>,
        "200g sokeria",<br></br>,
        "1/2 tl etikkaa (tai sitruunamehua)",<br></br>,
        "1/2 tl vaniljasokeria"
      ],
      ohjeet:
      [
        "1. Vatkaa valkuaiset kuohkeaksi vaahdoksi. Valkuaisvaahto on valmista, kun siihen alkaa muodostua pehmeitä huippuja.",<br></br>,

        "2. Lisää sokeri pienissä erissä vatkaten valkuaisia koko ajan keskinopeudella.",<br></br>,
        
        "3. Lisää lopuksi etikka ja vaniljasokeri.",<br></br>,
        
        "4. Vatkaa seosta voimakkaasti niin kauan kunnes marengista tulee kiiltävää ja se pitää muotonsa, kun käännät marengin ylösalaisin.",<br></br>,
        
        "5. Käytä pursotinpussissa pyöreää tyllaa tai leikkaa vain tasainen aukko pussin suulle. Pursota ensin pieni määrä marenkia leivinpaperille, kiinnitä suolatikku siihen ja pursota päälle muumio. Pursota halutessasi myös luita.",<br></br>,
        
        "6. Kiinnitä muumioille silmät. Jos sinulla ei ole valmiita silmiä, voit pursottaa silmät paiston jälkeen esim. tummasta suklaasulasta.",<br></br>,
        
        "7. Paista marenkeja uunin keskitasolla 100 asteessa (tai kiertoilmalla 75c) 2,5-3h. Tikkarit ovat valmiita, kun ne irtoavat helposti alustastaan, ja ovat rapeita sisältä.",<br></br>,
        
        "Jos teet pieniä marenkeja, paistoaikaa voi vähentää 1,5-2 tuntiin.",<br></br>,
        
        "Marengit voi jättää paiston jälkeen uuniin jäähtymään, ja uunin luukun raolleen.",<br></br>,
        
        "Marengit säilyy ilmatiiviisti pakattuna huoneenlämmössä useamman viikon."
      ]
    },
    {
      id: 4,
      kategoria: "kakut",
      title: "Vanilijakakkupohjat",
      monelle: "4 kakkupohjaa",
      laatija: "Ilona Tjurin",
      image: require('./Kuvat/vaniljakakkupohjat.jpg'),
      ainekset:
      [
        "3 munaa",<br></br>,
        "160g sokeria",<br></br>,
        "1dl maitoa",<br></br>,
        "50g voita",<br></br>,
        "180g jauhoja (n.3dl)",<br></br>,
        "1,5tl leivinjauhetta",<br></br>,
        "2tl vaniljasokeria",<br></br>,
        "hyppysellinen suolaa"
      ],
      ohjeet:
      [
        "1. Vuoraa leivinpaperilla kaksi halk. 15cm kakkuvuokaa.",<br></br>,

        "2. Vaahdota munat ja sokeri keskiteholla kuohkeaksi vaahdoksi, tähän menee 15-20min.",<br></br>,
        
        "3. Yhdistä maito ja voi kulhossa, ja lämmitä mikrossa siihen asti, että voi on sulanut. Sekoita.",<br></br>,
        
        "4. Yhdistä toisessa kulhossa keskenään kaikki kuivat aineet. Siivilöi.",<br></br>,
        
        "5. Lisää muna-sokerivaahtoon ensin puolet kuivista aineista ja sekoita nuolijalla tasaiseksi. Sen jälkeen lisää puolet voi-maitoseoksesta, sekoita tasaiseksi.",<br></br>,
        
        "6. Toista edelliset vaiheet. Sekoita vain siihen asti että kaikki ainekset ovat sekoittuneet, älä vatkaa.",<br></br>,
        
        "7. Jaa valmis taikina kahteen vuokaan.",<br></br>,
        
        "8. Paista 170 asteessa noin 30min. Testaa tikulla kypsyys.",<br></br>,
        
        "9. Jäähdytä kakkupohjia ensin 10-15min vuoissaan. Kumoa sen jälkeen ritilälle jäähtymään. Kääri jäähtyneet kakkupohjat kelmuun ja laita jääkaappiin mielellään yön yli."
      ]
    }
  ])


  return (
    <div className="home">
      {/*<Kortit resepti={resepti} />  */}
      <BrowserRouter>
      <Kategoriat />
      <Kakut resepti={resepti} title = 'Suosikit' />
      <Kakut resepti={resepti.filter((category) => category.kategoria === 'kakut')} title='Kakut ja kakkupohjat'/>
      </BrowserRouter>
    </div>
  )
};

export default KakkuApp;