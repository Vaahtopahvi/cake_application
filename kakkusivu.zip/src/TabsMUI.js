import React from 'react'
import DriveEtaIcon from '@mui/icons-material/DriveEta';
import { useState } from 'react';
import { Box, Tabs, Tab } from '@mui/material';
import Kakut from './components/Kakut';
import Marengit from './components/Marengit';

function TabsMUI() {
    const [value, setValue] = useState(0);

    const handleChange = (event, val) => {
        setValue( val );
    }

    return (
        <Box >
            <Tabs value= { value } onChange= { handleChange } >
                <Tab label='Kakut' icon={ <DriveEtaIcon /> } />
                <Tab label = 'Marengit' icon={ <DriveEtaIcon /> } />
            </Tabs>
            { value === 0 && <Kakut /> }
            { value === 1 && <Marengit /> }
            { value === 2 && <Kakut /> }
        </Box>
    )
}

export default TabsMUI