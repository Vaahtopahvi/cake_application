import React from 'react'

function NavBar() {
  return (
    <nav className='nav'>
        <a href="/" className='site-title'>
            Kakkusivu
        </a>
    </nav>
  )
}

export default NavBar