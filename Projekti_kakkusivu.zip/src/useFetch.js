import { useEffect, useState } from "react";

const useFetch = (url) => {
    const [data, setData] = useState(null); //reseptin arvo alustavasti on null
    const [ladataan, setLadataan] = useState(true);
    const [virhe, setVirhe] = useState(null);

    useEffect (() => {
        fetch( url )
          .then(res => {
            if(!res.ok) {                 //jos ei saada haettua tietoja databasesta niin heitetään error
              throw Error('Tietoja ei voitu hakea')
            }
            return res.json()             //otetaan tiedot data kansiosta (database) res(ponseen) ja käytetään json methodia
          })                              //sitten siirretään saadut tiedot data muuttujaan
          .then(data => {
            setData(data)
            setLadataan(false)            //muuta muuttuja 'ladataan' falseksi kun ollaan saatu data
            setVirhe(null)
          })
          .catch(virhe => {
            setLadataan(false)
            setVirhe(virhe.message)       //näytetään errorviesti
          })
    }, [url]);

    return { data, ladataan, virhe }
    
}


export default useFetch;